#include <stdio.h>
#include <string.h>
#include "esercizio1.h"

void setAddress(address *a)
{
    printf("\n Inserisci via: ");
    scanf("%s", a->via);
    printf("\n Inserisci civico: ");
    scanf("%s", a->civico);
    printf("\n Inserisci comune: ");
    scanf("%s", a->comune);
    printf("\n Inserisci cap: ");
    scanf("%s", a->cap);
    printf("\n Inserisci prov: ");
    scanf("%s", a->prov);
}

void printAddress(const address *a)
{
    printf("Via: %s\n", a->via);
    printf("Civico: %d\n", a->civico);
    printf("Comune: %s\n", a->comune);
    printf("cap: %d\n", a->cap);
    printf("prov: %s\n\n", a->prov);
}

void setName(char *s)
{
    printf("\n Inserisci name: ");
    scanf("%s", s);
}

void printName(const char *s)
{
    printf("name: %s\n", s);
}

void setSurname(char *s)
{
    printf("\n Inserisci surname: ");
    scanf("%s", s);
}

void printSurname(const char *s)
{
    printf("surname: %s\n", s);
}

void setPearson(pearson *p)
{
    setName(p->name);
    setSurname(p->surname);
    setAddress(&p->pearsonAddress);
}

void printPerson(const pearson *p)
{
    printName(p->name);
    printSurname(p->surname);
    printAddress(&p->pearsonAddress);
}

void initGroup(group *g)
{
    g->npers = 0;
}

int addPersonToGroup(const pearson *p, group *g)
{
    int res = 1; // true

    if (g->npers == MAX_PERS)
        res = 0; // false
    else
    {
        pearson *tmp = &g->people[g->npers];
        *tmp = *p;
        g->npers++;
        sortByName(g->people, g->npers);
        sortBySurname(g->people, g->npers);
    }

    return res;
}

void printGroupByName(const group *g)
{
    printPeopleArray(g->people, g->npers);
}

void printGroupBySurname(const group *g)
{
    printPeopleArray(g->people, g->npers);
}

void printPeopleArray(const pearson people[], int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        printPerson(&people[i]);
    }
}

void swap(pearson *p1, pearson *p2)
{
    pearson temp;
    temp = *p1;
    *p1 = *p2;
    *p2 = temp;
}

// Bubble sort procedure, for name
void sortByName(pearson people[], int n)
{
    int i, j;

    for (i = n - 1; i > 0; i--)
        for (j = 0; j < i; j++)
            if (strcmp(people[j].name, people[j + 1].name) > 0)
                swap(&people[j], &people[j + 1]);
}

// Bubble sort procedure, for surname
void sortBySurname(pearson people[], int n)
{
    int i, j;

    for (i = n - 1; i > 0; i--)
        for (j = 0; j < i; j++)
            if (strcmp(people[j].surname, people[j + 1].surname) > 0)
                swap(&people[j], &people[j + 1]);
}

pearson *searchByName(const char name[], const group *g)
{
    return searchByNameWrap(name, g->people, 0, g->npers - 1);
}

// Binary search procedure, for name
pearson *searchByNameWrap(const char name[], const pearson people[], int inizio, int fine)
{
    int pivot, cmp;
    pearson *res;
    if (inizio > fine)
        res = NULL;
    else
    {
        pivot = (inizio + fine) / 2;
        cmp = strcmp(people[pivot].name, name);
        if (cmp == 0)
            res = &people[pivot];
        else if (cmp > 0)
            res = searchByNameWrap(name, people, inizio, pivot - 1);
        else
            res = searchByNameWrap(name, people, pivot + 1, fine);
    }
    return res;
}

pearson *searchBySurname(const char surname[], const group *g)
{
    return searchBySurnameWrap(surname, g->people, 0, g->npers - 1);
}

// Binary search procedure, for surname
pearson *searchBySurnameWrap(const char surname[], const pearson people[], int inizio, int fine)
{
    int pivot, cmp;
    pearson *res;
    if (inizio > fine)
        res = NULL;
    else
    {
        pivot = (inizio + fine) / 2;
        cmp = strcmp(people[pivot].surname, surname);
        if (cmp == 0)
            res = &people[pivot];
        else if (cmp > 0)
            res = searchBySurnameWrap(surname, people, inizio, pivot - 1);
        else
            res = searchBySurnameWrap(surname, people, pivot + 1, fine);
    }
    return res;
}